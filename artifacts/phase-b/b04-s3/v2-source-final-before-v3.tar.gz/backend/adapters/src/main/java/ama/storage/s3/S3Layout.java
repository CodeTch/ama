package ama.storage.s3;

import ama.contract.StorageContracts.*;

final class S3Layout {
    final S3Config config;

    S3Layout(S3Config config) {
        this.config = config;
    }

    static String encode(String s) {
        var out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '~') out.append(c);
            else out.append('~').append(String.format(java.util.Locale.ROOT, "%04x", (int) c));
        }
        return out.toString();
    }

    static String decode(String s) {
        var out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '~') out.append(c);
            else {
                if (c != '~' || i + 4 >= s.length()) throw ControlCodec.unavailable();
                String h = s.substring(i + 1, i + 5);
                if (!h.matches("[0-9a-f]{4}")) throw ControlCodec.unavailable();
                int n = Integer.parseInt(h, 16);
                if (n < '~') throw ControlCodec.unavailable();
                out.append((char) n);
                i += 4;
            }
        }
        return out.toString();
    }

    String scope(String namespace) {
        return "data/v2/" + encode(config.backendId()) + "/" + encode(namespace) + "/";
    }

    String data(StorageKey k) {
        backend(k.backendId());
        String result = scope(k.namespace()) + encode(k.objectKey());
        if (result.length() > config.keyBudget())
            throw new StorageException(ErrorCode.INVALID_ARGUMENT);
        return result;
    }

    void backend(String id) {
        if (!config.backendId().equals(id)) throw ControlCodec.unavailable();
    }

    byte[] binding(StorageKey k) {
        data(k);
        return ControlCodec.pack(
                "key-v2", config.identity(), k.backendId(), k.namespace(), k.objectKey());
    }

    String bindingKey(StorageKey k) {
        return "keys/v1/"
                + ControlCodec.hash(
                        ControlCodec.pack(
                                "identity-v2", k.backendId(), k.namespace(), k.objectKey()))
                + "/spec";
    }
}
